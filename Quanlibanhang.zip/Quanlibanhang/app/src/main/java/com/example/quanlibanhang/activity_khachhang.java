package com.example.quanlibanhang;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class activity_khachhang  extends AppCompatActivity {
    EditText maKH, tenKH, diachi, sdt;
    TextView maKHtv;
    Button ok,huy;
    database dbmh;
    ArrayList <KhachHang> data = new ArrayList<KhachHang>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_khachhang);
        setControl();
        setEvent();
    }

    public void setControl()
    {
        maKH=findViewById(R.id.maKHEt);
        tenKH=findViewById(R.id.tenKHEt);
        diachi=findViewById(R.id.diachiet);
        sdt=findViewById(R.id.sdtet);
        ok=findViewById(R.id.okbtkh);
        huy=findViewById(R.id.huybtkh);
        maKHtv=findViewById(R.id.mahang_kh);
    }

    public void setEvent()
    {
        dbmh=new database(this);
        Intent intent =getIntent();
        final int vitri = intent.getIntExtra("vitriKH",0);

        int role=intent.getIntExtra("roleKH",-2);
        //nếu màn hình kia bấm nút sửa
        if (role==-1)
        {
            //lay du lieu tu database va gan vao mang data
            capNhatDuLieu();

            tenKH.setText(data.get(vitri).getTenKH());
            diachi.setText(data.get(vitri).getDiaChi());
            sdt.setText(data.get(vitri).getSDT());
            maKH.setText(data.get(vitri).getMaKH());
            maKH.setEnabled(false);
            ok.setOnClickListener(new View.OnClickListener() {
                //click vào button ok thì dữ liêu lấy từ giao diện được lưu vào class
                @Override
                public void onClick(View v) {
                    KhachHang kh=data.get(vitri);
                    kh.setTenKH(tenKH.getText().toString());
                    kh.setDiaChi(diachi.getText().toString());
                    kh.setSDT(sdt.getText().toString());
                    dbmh.suaKhachHang(kh);
                    Toast.makeText(getApplicationContext(), "Chỉnh sửa thành công", Toast.LENGTH_LONG).show();

                }
            });

        }

//nút thêm
        if(role!=-1) {
            maKH.setVisibility(View.INVISIBLE);
            maKHtv.setVisibility(View.INVISIBLE);
            ok.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {



                    if (tenKH.getText().toString().equals("")) {
                        tenKH.setError("ban phai nhap ten KH");
                        tenKH.requestFocus();
                        return;
                    }
                    if (diachi.getText().toString().equals("")) {
                        diachi.setError("ban phai nhap dia chi");
                        diachi.requestFocus();
                        return;
                    }
                    if (sdt.getText().toString().equals("")) {
                        sdt.setError("ban phai nhap sdt");
                        sdt.requestFocus();
                        return;
                    }

                    KhachHang kh = layDLTuGiaoDien();
                    dbmh.ThemKhachHang(kh);
                    Toast.makeText(getApplicationContext(), "Thêm khách hàng thành công", Toast.LENGTH_LONG).show();
                }

            });}
        huy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_khachhang.this, listview_khachhang.class);
                startActivity(intent);
            }
        });


    }
    public KhachHang layDLTuGiaoDien(){
        KhachHang kh =new KhachHang();
        kh.setTenKH(tenKH.getText().toString());
        kh.setDiaChi(diachi.getText().toString());
        kh.setSDT(sdt.getText().toString());
        return kh;
    }


    public void capNhatDuLieu() {
        Cursor cursor = dbmh.LayTatCaDuLieuKhachHang();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                KhachHang kh =new KhachHang();
                kh.setMaKH("" + cursor.getInt(0));
                kh.setTenKH(cursor.getString(1));
                kh.setDiaChi(cursor.getString(2));
                kh.setSDT( cursor.getString(3));
                data.add(kh);

            }

        }


    }
}
